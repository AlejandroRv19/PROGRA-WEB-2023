import React from 'react'

export const HomePage = () => {
  return (
    <h1>Welcome back to homepage</h1>
  )
}
